# edge_detector/__init__.py
"""
Pacote para detecção de bordas usando OpenCV.
"""
